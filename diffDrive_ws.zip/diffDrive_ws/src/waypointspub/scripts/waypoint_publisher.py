import rospy
from geometry_msgs.msg import PoseStamped

def create_waypoints():
    # Define waypoints from the /amcl_pose data
    waypoints = [
        {"position": {"x": 2.09684049429, "y": 0.325454393326}, "orientation": {"z": -0.0866640310551, "w": 0.996237595015}},
        {"position": {"x": 0.954651324826, "y": -0.184147205}, "orientation": {"z": 0.34851341439, "w": 0.937303792796}},
        {"position": {"x": 1.52008607094, "y": 0.599686194955}, "orientation": {"z": -0.133006147589, "w": 0.991115212628}},
        {"position": {"x": 1.64548720172, "y": 0.324862019537}, "orientation": {"z": -0.012756548341, "w": 0.999918631927}},
        {"position": {"x": 3.52461477591, "y": 1.06986450026}, "orientation": {"z": -0.994595131819, "w": 0.103829301079}},
        {"position": {"x": 2.96109035342, "y": 0.831433825694}, "orientation": {"z": -0.98112116853, "w": 0.193394034711}},
        {"position": {"x": 2.38201974344, "y": 0.560795676423}, "orientation": {"z": -0.975052269004, "w": 0.221975387621}},
        {"position": {"x": 1.95740362527, "y": 0.563496740509}, "orientation": {"z": 0.990122007037, "w": 0.140208456168}},
        {"position": {"x": 3.51668636651, "y": 0.857802009295}, "orientation": {"z": -0.0734991725423, "w": 0.997295278057}},
        {"position": {"x": 3.93812470552, "y": 0.825962948932}, "orientation": {"z": -0.052176269391, "w": 0.998637890785}},
        {"position": {"x": 4.32269559964, "y": 0.819062356198}, "orientation": {"z": -0.035322494483, "w": 0.999375965983}},
    ]
    return waypoints

def publish_waypoints():
    rospy.init_node('waypoint_publisher', anonymous=True)
    waypoint_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
    rate = rospy.Rate(1)  # Publish at 1 Hz

    waypoints = create_waypoints()
    for waypoint in waypoints:
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.pose.position.x = waypoint["position"]["x"]
        pose.pose.position.y = waypoint["position"]["y"]
        pose.pose.position.z = 0.0
        pose.pose.orientation.x = 0.0
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = waypoint["orientation"]["z"]
        pose.pose.orientation.w = waypoint["orientation"]["w"]

        rospy.loginfo(f"Publishing waypoint: {pose}")
        waypoint_pub.publish(pose)
        rate.sleep()

if __name__ == '__main__':
    try:
        publish_waypoints()
    except rospy.ROSInterruptException:
        pass
